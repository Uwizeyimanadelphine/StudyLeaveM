package com.finalproject.urproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UrprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
